from django.contrib import admin

from myapp.models import *  # Student, Book

# Register your models here.
admin.site.register(Student)
admin.site.register(Book)
admin.site.register(Course)
admin.site.register(Profile)