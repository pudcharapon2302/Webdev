from django.db import models

# Create your models here.
class Student(models.Model):
    name = models.CharField(max_length=200)
    dob = models.DateField()
    email = models.EmailField()

    def __str__(self):
        return self.name

class Book(models.Model):
    author = models.ForeignKey(Student, 
                               on_delete=models.DO_NOTHING, 
                               blank=True, 
                               null=True,
                               verbose_name='ผู้แต่ง')  # CASCADE)

    title = models.CharField(max_length=500,
                                verbose_name='ชื่อเรื่อง') 

    price = models.FloatField(default=500.0,
                                verbose_name='ราคา')


    def __str__(self):
        return f'หนังสือเรื่อง{self.title} แต่งโดย{self.author} ราคา {self.price} บาท'

class Course(models.Model):
    students = models.ManyToManyField(Student)

class Profile(models.Model):
    student = models.OneToOneField(Student, on_delete=models.DO_NOTHING)
    picture = models.ImageField(upload_to='profile/')